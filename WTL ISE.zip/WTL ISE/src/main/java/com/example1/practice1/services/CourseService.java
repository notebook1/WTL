package com.example1.practice1.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example1.practice1.Entity.Course;
import com.example1.practice1.Repository.CourseRepository;

@Service
public class CourseService {
    
    @Autowired
    private CourseRepository courseRepository;

    public Course addCourse(Course course)
    {
      return courseRepository.save(course);
    }

    public List<Course> Getcourses(){
      return courseRepository.findAll();
    }

    public Course GetcourseByid(Integer id) {
        return courseRepository.findById(id).orElse(null);
    }

    public void deletecourse(Integer id) {
         this.courseRepository.deleteById(id);
    }

    public Course updateproduct(Course product, Integer id) {
       Course cours = courseRepository.findById(id).get();
       cours.setName(product.getName());
      return courseRepository.save(cours);
    }


}
