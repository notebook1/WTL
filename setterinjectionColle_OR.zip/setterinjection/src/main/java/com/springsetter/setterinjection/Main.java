package com.springsetter.setterinjection;

/**
 * Hello world!
 *
 */
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

//import com.springcore.Employee;
 
// Application (Main) Class
public class Main {
 
    // Main driver method
    public static void main(String[] args)
    {
        // Creating a new class path resource
        Resource resource = new ClassPathResource(
            "applicationContext.xml");
 
        // Creating an object of BeanFactory class
        BeanFactory factory = new XmlBeanFactory(resource);
 
        // Creating an object of Employee class
        Company e = (Company)factory.getBean("company");
 
        // Calling display() method inside main() method
       System.out.println(e);
    }
}