package com.springsetter.setterinjection;
import java.util.*;

public class Company {
	
	// Class data members
    private String companyName;
    private List<String> employees;
 
    // Setter
    public void setCompanyName(String companyName)
    {
        this.companyName = companyName;
    }
 
    // Setter
    public void setEmployees(List<String> employees)
    {
        this.employees = employees;
    }
 
    // Getter
    public String getCompanyName() { return companyName; }
 
    // Getter
    public List<String> getEmployees() { return employees; }

	@Override
	public String toString() {
		return "Company [companyName=" + companyName + ",\n" +"employees=" + employees + "]";
	}
 
    
    

	// Method
//    public void display()
//    {
//        System.out.println("Company: " + companyName);
//        System.out.println("Employee list: " + companyName);
// 
//        // Iterating over using for each loop
//        for (String employee : employees) {
//            System.out.println("-" + employee);
//        }
//    }

}
