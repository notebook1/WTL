package com.example1.practice1.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example1.practice1.Entity.Teacher;
import com.example1.practice1.Repository.TeacherRepository;

@Service
public class TeacherService {
    
    @Autowired
    private TeacherRepository teachRepository;

    public Teacher addTeacher(Teacher teach)
    {
      return teachRepository.save(teach);
    }

    public List<Teacher> Getteachers(){
      return teachRepository.findAll();
    }

    public Teacher GetteacherByid(Integer id) {
        return teachRepository.findById(id).orElse(null);
    }

    public void deleteteacher(Integer id) {
         this.teachRepository.deleteById(id);
    }

    public Teacher updateteacher(Teacher teacher, Integer id) {
       Teacher teach = teachRepository.findById(id).get();
       teach.setName(teacher.getName());
       teach.setSalary(teacher.getSalary());
      return teachRepository.save(teach);
    }


}
