package com.example1.practice1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example1.practice1.Entity.Course;
import com.example1.practice1.services.CourseService;

@RestController
public class CourseController {
    
    @Autowired
    private CourseService courseService;

    @PostMapping("/saveCourse")
    public Course course( @RequestBody Course course)
    {
        return courseService.addCourse(course) ;
    }

    @GetMapping("/getCourses")
    public List<Course> findallProducts()
    {
        return courseService.Getcourses();
    }

     @GetMapping("/getcourseByid/{id}")
    public Course findCoursebyId(@PathVariable Integer id)
    {
        return courseService.GetcourseByid(id);
    }

    @DeleteMapping("/deleteCourse/{id}")
    public String deleteProductbyId(@PathVariable Integer id)
    {
        courseService.deletecourse(id);
        return "Course deleated successsfully";
    }
    
    @PutMapping("/updateCourse/{id}")
    public Course updateStudent(@RequestBody Course course,@PathVariable Integer id)
    {
      return courseService.updateproduct(course, id);
    }

}
