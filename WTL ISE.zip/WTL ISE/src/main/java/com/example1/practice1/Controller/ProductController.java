package com.example1.practice1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example1.practice1.Entity.Product;
import com.example1.practice1.services.ProductService;

@RestController
public class ProductController {
    
    @Autowired
    private ProductService productService;

    @PostMapping("/saveProduct")
    public Product product( @RequestBody Product product)
    {
        return productService.addProduct(product) ;
    }

    @GetMapping("/getProducts")
    public List<Product> findallProducts()
    {
        return productService.Getproducts();
    }

     @GetMapping("/getproductByid/{id}")
    public Product findProductbyId(@PathVariable Integer id)
    {
        return productService.GetproductByid(id);
    }

    @DeleteMapping("/deleteProduct/{id}")
    public String deleteProductbyId(@PathVariable Integer id)
    {
        productService.deleteProduct(id);
        return "Product deleated successsfully";
    }
    
    @PutMapping("/updateProduct/{id}")
    public Product updateStudent(@RequestBody Product product,@PathVariable Integer id)
    {
      return productService.updateproduct(product, id);
    }

}
