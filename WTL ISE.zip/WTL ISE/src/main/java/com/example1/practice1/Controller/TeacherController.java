package com.example1.practice1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example1.practice1.Entity.Teacher;
import com.example1.practice1.services.TeacherService;

@RestController
public class TeacherController {
    
    @Autowired
    private TeacherService teacherservice;

    @PostMapping("/addTeacher")
    public Teacher teacher( @RequestBody Teacher teacher)
    {
        return teacherservice.addTeacher(teacher);
    }

    @GetMapping("/getallTeachers")
    public List<Teacher> teacher()
    {
        return teacherservice.Getteachers();
    }

    @GetMapping("/getteachersByid/{id}")
    public Teacher teachera(@PathVariable Integer id)
    {
        return teacherservice.GetteacherByid(id);
    }

    @DeleteMapping("/deleteTeacher/{id}")
    public String deletTeacherbyId(@PathVariable Integer id)
    {
        teacherservice.deleteteacher(id);
        return "Teacher deleated successsfully";
    }
    
    @PutMapping("/updateTeacher/{id}")
    public Teacher updateTeacher(@RequestBody Teacher teacher,@PathVariable Integer id)
    {
      return teacherservice.updateteacher(teacher, id);
    }

}
