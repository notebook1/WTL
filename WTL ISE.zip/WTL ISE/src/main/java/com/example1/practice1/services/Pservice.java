package com.example1.practice1.services;

import java.util.List;
import com.example1.practice1.Entity.Product;

public interface Pservice {
    
    public Product RegisterStudent(Product product);
    List<Product> Getproducts();
    public void deleteProduct(Integer id);
    public Product GetproductByid(Integer id);
    public Product updateproduct(Product product,Integer id);
}
