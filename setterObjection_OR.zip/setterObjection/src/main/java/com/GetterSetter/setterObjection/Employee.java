package com.GetterSetter.setterObjection;

class Employee {

	// Class member members
	private String name;
	private String employeeID;
	private String department;
	private Address address;

	// Setter
	public void setName(String name) { this.name = name; }

	// Setter
	public void setemployeeID(String employeeID)
	{
		this.employeeID = employeeID;
	}

	// Setter
	public void setdepartment(String department)
	{
		this.department = department;
	}

	// Setter
	public void setAddress(Address address)
	{
		this.address = address;
	}

	// Getter
	public String getName() { return name; }

	// Getter
	public String getemployeeID() { return employeeID; }

	// Getter
	public String getdepartment() { return department; }

	// Getter
	public Address getAddress() { return address; }

	@Override
	public String toString() {
		return "Employee [name=" + name + ", employeeID=" + employeeID + ", department=" + department + ", address="
				+ address + "]";
	}

	// Method
	
}

